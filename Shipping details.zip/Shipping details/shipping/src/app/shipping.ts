export class Shipping{
    ShippingId:number;
    CustomerId:string;
    CustomerName:string;
    OrderID:string;
    ShippingAddress:string;
    }