
import { Injectable } from '@angular/core';
import { Shipping } from './Shipping';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ShippingService {

  constructor(private httpClient: HttpClient) {

    this.getShippingDetails().subscribe(data => this.shippingList = data);
  }

  shippingList: Array<Shipping> = [];

  url: string = "http://localhost:8084/view/";


  getShippingDetails(): any {
    return this.httpClient.get<Shipping>(this.url);
  }
}
